#!/bin/bash
$QUALNET_HOME/bin/qualnet up.config 2>error.log
