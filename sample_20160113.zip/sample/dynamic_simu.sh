#!/bin/bash
if [ "$#" -lt 2 ] || [ "$#" -gt 4 ] ; then
	echo "Usage: $0 CASE PLAN [POLICY] [SPECS]" >&2
	echo
	exit 1
fi

cp up.app.part up.app
cp up.config.part dynamic_up.config
cat $1 >> dynamic_up.config
echo "UP 104 101 MDC path $2 $3 $4" >> up.app
./dynamic_run.sh
