#!/bin/bash
if [ "$#" -ne 1 ] || ! [ -f "$1" ] ; then
	echo "Usage: $0 PLAN" >&2
	echo
	exit 1
fi

cp up.app.part up.app
echo "UP 104 101 MDC path $1" >> up.app
./run.sh
