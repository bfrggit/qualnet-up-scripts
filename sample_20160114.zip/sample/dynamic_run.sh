#!/bin/bash
$QUALNET_HOME/bin/qualnet dynamic_up.config 2>error.log
