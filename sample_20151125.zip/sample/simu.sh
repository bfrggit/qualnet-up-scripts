#!/bin/bash
if [ "$#" -ne 1 ] || ! [ -f "$1" ] ; then
	echo "Usage: $0 PLAN" >&2
	echo
	exit 1
fi

cp /home/charles/tmp/qualnet-simu/sample/up.test.app /home/charles/tmp/qualnet-simu/sample/up.app
sed -i -- "s/-/$1/g" up.app
./run.sh
