$QUALNET_HOME/bin/qualnet up.test.config

