$QUALNET_HOME/bin/qualnet up.config

